<?php

class IndexController extends pm_Controller_Action
{

	protected $_accessLevel = [
		'admin'
	];

	public function indexAction()
	{
		$this->view->pageTitle = 'We Sell In - Automatic Installer';
		
		$this->view->list = $this->_getDomainsList();
	}
	
	private function _getDomainsList()
	{
		
		$data = [];
		$domains = pm_Domain::getAllDomains();
		
		$index = 0;
		foreach ($domains as $domain) {
			$domainDocumentRoot = $domain->getDocumentRoot();
			$domainName = $domain->getName();
			$domainIsActive = $domain->isActive();
			$domainCreation = $domain->getProperty('cr_date');
			
			$data[$index] = [
				'domain' => '<a href="#">'.$domainName.'</a>',
				'created_date' => $domainCreation,
				'active' => ($domainIsActive ? 'Yes' : 'No')
			];
			$index++;
		}
		
		$options = [
			'defaultSortField' => 'active',
			'defaultSortDirection' => pm_View_List_Simple::SORT_DIR_DOWN,
		];
		$list = new pm_View_List_Simple($this->view, $this->_request, $options);
		$list->setData($data);
		$list->setColumns([
			pm_View_List_Simple::COLUMN_SELECTION,
			'domain' => [
				'title' => 'Domain',
				'noEscape' => true,
				'searchable' => true,
			],
			'created_date' => [
				'title' => 'Created Date',
				'noEscape' => true,
				'searchable' => true,
			],
			'active' => [
				'title' => 'Active',
				'noEscape' => true,
				'sortable' => false,
			],
		]);
		
		// Take into account listDataAction corresponds to the URL /list-data/
		$list->setDataUrl(['action' => 'list-data']);
		
		return $list;
	}
}