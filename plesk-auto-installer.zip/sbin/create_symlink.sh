#!/bin/bash -e

whoami

exit 0