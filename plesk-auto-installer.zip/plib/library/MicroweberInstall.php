<?php

class Modules_CredoCart_Install {
	
	use AppDefaultInstall;
	
    protected $_scriptFolder = '/usr/share/microweber/latest';

    public function run() {
        
    	echo 'Microweber install';
    	
    }
}