<?php 

$config = array();
$config['name'] = 'Microweber';
$config['description'] = '';




return $config;