# plesk-auto-installer

/opt/psa/admin/sbin/modules/wesellin

# Panel.ini
[ext-catalog]
extensionUpload = true

[php]
settings.general.open_basedir.default="none"